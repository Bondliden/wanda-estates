
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getExpertInsight(context: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Como consultor experto en marketing inmobiliario 2025, profundiza en este punto de la auditoría: ${context}. Explica brevemente por qué es vital para el mercado de lujo de Marbella hoy en día.`,
      config: {
        temperature: 0.7,
        maxOutputTokens: 300,
      }
    });
    return response.text || "No se pudo generar el insight experto.";
  } catch (error) {
    console.error("Error fetching Gemini insight:", error);
    return "Error al conectar con la IA de consultoría.";
  }
}
