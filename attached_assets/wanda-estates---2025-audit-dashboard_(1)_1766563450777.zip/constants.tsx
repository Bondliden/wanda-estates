
import React from 'react';
import { AuditItem, PillarType, PillarInfo } from './types';

export const PILLARS: PillarInfo[] = [
  {
    type: PillarType.COPY,
    icon: '✍️',
    description: 'Ingeniería de la Persuasión y Proyección a Futuro.'
  },
  {
    type: PillarType.UX,
    icon: '🎨',
    description: 'Retención, Velocidad y Jerarquía Visual.'
  },
  {
    type: PillarType.SEO,
    icon: '📍',
    description: 'Hiperlocalización y Prueba Social.'
  },
  {
    type: PillarType.LEADS,
    icon: '📈',
    description: 'Estrategias de Conversión sin Fricción.'
  },
  {
    type: PillarType.INNOVATION,
    icon: '🤖',
    description: 'Inteligencia Artificial y Experiencias Inmersivas.'
  }
];

export const AUDIT_DATA: AuditItem[] = [
  {
    pillar: PillarType.COPY,
    element: "Titular Principal (Hero Section)",
    reason: "Actualmente es descriptivo y frío. No conecta con la emoción de exclusividad del inversor de Marbella.",
    suggestion: "Cambiar a: 'Tu Legado en la Costa del Sol: Propiedades que Definen un Estilo de Vida Extraordinario'. Sustituir 'Ver Propiedades' por 'Explorar tu Próximo Refugio'.",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4" 
  },
  {
    pillar: PillarType.COPY,
    element: "Narrativa de Listados",
    reason: "Las descripciones son listas técnicas de metros y habitaciones. Falta 'Future Pacing'.",
    suggestion: "Usar lenguaje sensorial: 'Tres suites de ensueño donde el amanecer sobre el Mediterráneo es tu despertador natural'. En lugar de 'orientación sur', usar 'luz natural ininterrumpida que abraza cada rincón'."
  },
  {
    pillar: PillarType.UX,
    element: "Optimización Mobile-First",
    reason: "Los botones de contacto son pequeños (fricción táctil). El 70% de tus leads llegan por smartphone.",
    suggestion: "Implementar áreas de clic de 48x48px. Cambiar el texto de 'Contacto' a 'Programar Visita VIP' para elevar el estatus de la acción.",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
  },
  {
    pillar: PillarType.UX,
    element: "Jerarquía Visual (Bento-Box)",
    reason: "La disposición lineal actual satura al usuario y no destaca la propiedad estrella.",
    suggestion: "Reorganizar la home con diseño Bento-Box: destacar 'La Villa del Mes' en un módulo grande y 'Guías de Inversión' en módulos laterales minimalistas."
  },
  {
    pillar: PillarType.SEO,
    element: "Hiperlocalización Local",
    reason: "Búsquedas genéricas de 'Marbella'. Falta captura de tráfico long-tail por barrios específicos.",
    suggestion: "Crear páginas pilar para: 'Villas en La Zagaleta', 'Apartamentos en Puerto Banús' y 'Áticos en Sierra Blanca', incluyendo puntos de interés como clubes de golf y colegios."
  },
  {
    pillar: PillarType.SEO,
    element: "Prueba Social (Trust Signals)",
    reason: "No hay reseñas visibles. La confianza es el motor principal en transacciones de alto ticket.",
    suggestion: "Integrar widget dinámico de Google Reviews y Trustpilot. Añadir una sección de 'Casos de Éxito: De Propiedad a Hogar'."
  },
  {
    pillar: PillarType.LEADS,
    element: "Lead Magnets de Valor",
    reason: "Solo tienes un formulario de contacto genérico. Estás perdiendo el 90% de leads que no están listos para comprar hoy.",
    suggestion: "Añadir botón: 'Descargar Guía de Impuestos y Gastos de Compra en España 2025' o 'Calculadora de ROI Marbella Exclusive'."
  },
  {
    pillar: PillarType.LEADS,
    element: "Fricción en Formularios",
    reason: "Pedir el teléfono de entrada reduce la conversión en un mercado de lujo que valora la discreción.",
    suggestion: "Pedir solo Nombre y Email inicialmente. Ofrecer el teléfono como opcional para 'Atención Prioritaria vía WhatsApp'."
  },
  {
    pillar: PillarType.INNOVATION,
    element: "Asistente IA 24/7",
    reason: "Los clientes de Arabia Saudí o EE.UU. visitan la web mientras tu equipo duerme.",
    suggestion: "Implementar un Agente IA entrenado para responder dudas sobre gastos de comunidad, IBI y servicios locales al instante."
  },
  {
    pillar: PillarType.INNOVATION,
    element: "Experiencia Multimedia 360",
    reason: "Falta de inmersión. Las fotos estáticas ya no son suficientes para el comprador internacional.",
    suggestion: "Integrar 'Cinematic Tours' con drones y Matterport 3D en cada ficha. El video aumenta las consultas un 403% según datos de 2025.",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
  }
];
