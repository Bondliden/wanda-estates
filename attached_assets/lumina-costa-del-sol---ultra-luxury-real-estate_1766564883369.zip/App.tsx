
import React from 'react';
import { Property } from './types';
import Header from './components/Header';
import Hero from './components/Hero';
import PropertyCard from './components/PropertyCard';
import InsightSection from './components/InsightSection';

const PROPERTIES: Property[] = [
  {
    id: '1',
    title: 'Villa Altair: Arquitectura de Vanguardia',
    location: 'La Zagaleta, Marbella',
    price: '12.500.000 €',
    description: 'Una residencia donde la materialidad noble y la integración paisajística definen el nuevo estándar del lujo discreto. Diseñada para quienes valoran la privacidad absoluta.',
    features: ['800m² construidos', 'Parcela de 3.500m²', 'Seguridad 24/7'],
    imageUrl: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1600'
  },
  {
    id: '2',
    title: 'Penthouse Horizon: El Legado del Mar',
    location: 'Puente Romano, Golden Mile',
    price: '6.800.000 €',
    description: 'Ático dúplex de diseño minimalista con terrazas que se funden con el horizonte. Un activo inmobiliario de valor excepcional.',
    features: ['Acceso directo al mar', 'Domótica avanzada', 'Solárium privado'],
    imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6191dae10c?auto=format&fit=crop&q=80&w=1600'
  }
];

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#fafafa] selection:bg-stone-200">
      <Header />
      
      <main>
        <Hero 
          title="Más que una propiedad, un legado frente al Mediterráneo: Donde el lujo y la calma se encuentran."
          subtitle="Privacidad, diseño y estilo en la Costa del Sol. Viva donde otros sueñan vacacionar."
          body="Imagina despertar cada día con vistas panorámicas al mar, donde la luz natural inunda cada rincón de su hogar. En nuestra exclusiva selección de propiedades, no solo encontrará metros cuadrados, sino un refugio sereno diseñado para elevar su calidad de vida."
        />

        <section id="properties" className="max-w-7xl mx-auto px-6 py-24">
          <div className="mb-16">
            <h2 className="text-4xl font-serif text-stone-900 mb-4 tracking-tight">Colección Seleccionada</h2>
            <div className="w-20 h-0.5 bg-stone-300"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-20">
            {PROPERTIES.map(property => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        </section>

        <InsightSection />
      </main>

      <footer className="bg-stone-900 text-stone-400 py-20 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center">
          <div className="mb-10 md:mb-0">
            <h2 className="text-2xl font-serif text-white tracking-[0.3em]">LUMINA</h2>
            <p className="text-[10px] uppercase tracking-[0.4em] mt-3 opacity-50">Patrimonio & Arquitectura</p>
          </div>
          <div className="text-[10px] tracking-[0.2em] uppercase space-y-2 opacity-60">
            <p>© 2024 Lumina Real Estate. Todos los derechos reservados.</p>
            <p>Estrategia Patrimonial en la Costa del Sol.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
