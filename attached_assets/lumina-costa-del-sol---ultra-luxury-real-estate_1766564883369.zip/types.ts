
export interface Property {
  id: string;
  title: string;
  location: string;
  price: string;
  description: string;
  features: string[];
  imageUrl: string;
}

export enum SectionType {
  HERO = 'HERO',
  LISTING = 'LISTING',
  AI_INSIGHT = 'AI_INSIGHT'
}
