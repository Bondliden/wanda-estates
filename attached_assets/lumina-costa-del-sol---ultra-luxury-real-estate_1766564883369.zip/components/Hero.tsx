
import React, { useEffect, useRef } from 'react';

interface HeroProps {
  title: string;
  subtitle: string;
  body: string;
}

const Hero: React.FC<HeroProps> = ({ title, subtitle, body }) => {
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!contentRef.current) return;
      const { clientX, clientY } = e;
      // Movimiento etéreo y suave
      const x = (clientX / window.innerWidth - 0.5) * 15;
      const y = (clientY / window.innerHeight - 0.5) * 15;
      contentRef.current.style.transform = `translate(${x}px, ${y}px)`;
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section className="relative h-screen flex items-center pt-20 overflow-hidden bg-black">
      {/* Video de Fondo Existente */}
      <div className="absolute inset-0 z-0">
        <video 
          autoPlay 
          loop 
          muted 
          playsInline
          className="w-full h-full object-cover brightness-[0.55] scale-105"
        >
          <source src="https://assets.mixkit.co/videos/preview/mixkit-luxury-villa-with-a-pool-at-sunset-34531-large.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-transparent"></div>
      </div>

      <div 
        ref={contentRef} 
        className="relative z-10 max-w-7xl mx-auto px-6 w-full transition-transform duration-1000 ease-out will-change-transform"
      >
        <div className="max-w-4xl">
          <div className="overflow-hidden mb-6">
            <p className="text-[10px] tracking-[0.6em] uppercase text-white/50 font-bold animate-[slide-reveal_1.5s_ease-out_forwards]">
              Propiedades de Inversión Seleccionadas
            </p>
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif text-white leading-[1.1] mb-8 drop-shadow-lg animate-[reveal-up_1.5s_cubic-bezier(0.16,1,0.3,1)]">
            {title}
          </h1>
          
          <p className="text-xl md:text-2xl font-light text-stone-200 mb-10 tracking-wide leading-relaxed animate-[fade-in_2s_ease-out_forwards] opacity-0" style={{ animationDelay: '0.4s' }}>
            {subtitle}
          </p>

          <div className="relative pl-8 border-l border-white/30 animate-[fade-in-up_2s_ease-out_forwards] opacity-0" style={{ animationDelay: '0.8s' }}>
            <p className="text-lg text-stone-300 mb-10 font-light italic max-w-2xl leading-relaxed">
              "{body}"
            </p>
            
            <button className="group relative flex items-center space-x-6 text-white text-[11px] font-bold tracking-[0.4em] uppercase transition-all">
              <span className="relative">
                Descubra su próximo activo
                <span className="absolute -bottom-2 left-0 w-0 h-px bg-white group-hover:w-full transition-all duration-500 ease-in-out"></span>
              </span>
              <span className="transform group-hover:translate-x-3 transition-transform duration-500 text-lg">→</span>
            </button>
          </div>
        </div>
      </div>

      {/* Indicador de desplazamiento lateral */}
      <div className="absolute bottom-12 right-12 z-10 flex items-center space-x-6 opacity-20">
        <div className="text-[9px] tracking-[0.5em] uppercase text-white font-bold rotate-90 origin-right translate-y-full">
          Scroll
        </div>
        <div className="w-px h-20 bg-gradient-to-b from-white to-transparent"></div>
      </div>

      <style>{`
        @keyframes reveal-up {
          from { transform: translateY(30px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        @keyframes slide-reveal {
          from { transform: translateX(-20px); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes fade-in-up {
          from { transform: translateY(15px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
      `}</style>
    </section>
  );
};

export default Hero;
