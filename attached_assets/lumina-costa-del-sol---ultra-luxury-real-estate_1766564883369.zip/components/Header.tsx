
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#fafafa]/80 backdrop-blur-md border-b border-stone-100">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <div className="text-2xl font-serif tracking-[0.2em] text-stone-900">LUMINA</div>
        <nav className="hidden md:flex space-x-10 text-sm font-medium tracking-widest text-stone-600 uppercase">
          <a href="#" className="hover:text-stone-900 transition-colors">Propiedades</a>
          <a href="#" className="hover:text-stone-900 transition-colors">Arquitectura</a>
          <a href="#" className="hover:text-stone-900 transition-colors">Contacto</a>
        </nav>
        <button className="text-xs font-bold tracking-[0.15em] uppercase border border-stone-300 px-6 py-2.5 hover:bg-stone-900 hover:text-white transition-all">
          Reservar Cita
        </button>
      </div>
    </header>
  );
};

export default Header;
