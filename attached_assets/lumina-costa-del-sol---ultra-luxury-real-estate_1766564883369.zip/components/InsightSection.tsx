
import React, { useState } from 'react';
import { generateInvestmentInsight } from '../services/geminiService';

const InsightSection: React.FC = () => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    const result = await generateInvestmentInsight(
      "Mercado de Lujo en Costa del Sol",
      "Analizamos activos de alta gama con enfoque en rentabilidad por escasez de suelo y diseño exclusivo."
    );
    setInsight(result || null);
    setLoading(false);
  };

  return (
    <section className="bg-stone-100 py-24 px-6">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-serif text-stone-900 mb-6">Perspectiva Analítica</h2>
        <p className="text-stone-600 mb-10 max-w-2xl mx-auto">
          Para el inversor sofisticado, la adquisición inmobiliaria trasciende el aspecto estético. 
          Utilizamos inteligencia de datos para curar informes exclusivos sobre el potencial patrimonial de nuestras propiedades.
        </p>
        
        <div className="min-h-[150px] flex flex-col items-center justify-center">
          {insight ? (
            <div className="bg-white p-10 shadow-sm border border-stone-200 animate-fade-in">
              <p className="text-xl font-serif italic text-stone-800 leading-relaxed">
                "{insight}"
              </p>
              <button 
                onClick={() => setInsight(null)}
                className="mt-6 text-xs font-bold tracking-widest uppercase text-stone-400 hover:text-stone-900 transition-colors"
              >
                Cerrar Informe
              </button>
            </div>
          ) : (
            <button 
              onClick={handleGenerate}
              disabled={loading}
              className="group flex flex-col items-center space-y-4"
            >
              <div className={`w-16 h-16 rounded-full border border-stone-300 flex items-center justify-center group-hover:bg-stone-900 group-hover:text-white transition-all duration-500 ${loading ? 'animate-pulse' : ''}`}>
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <span className="text-xs font-bold tracking-[0.2em] uppercase text-stone-500">
                {loading ? 'Generando Análisis...' : 'Solicitar Análisis de Inversión'}
              </span>
            </button>
          )}
        </div>
      </div>
    </section>
  );
};

export default InsightSection;
