
import React from 'react';
import { Property } from '../types';

interface PropertyCardProps {
  property: Property;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ property }) => {
  return (
    <div className="group cursor-pointer">
      <div className="relative aspect-[16/10] overflow-hidden mb-6">
        <img 
          src={property.imageUrl} 
          alt={property.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute top-4 right-4 bg-white/90 px-4 py-2 text-xs font-bold tracking-widest uppercase">
          {property.price}
        </div>
      </div>
      <div className="space-y-3">
        <p className="text-stone-500 text-xs font-bold tracking-[0.2em] uppercase">
          {property.location}
        </p>
        <h3 className="text-2xl font-serif text-stone-900 group-hover:text-stone-600 transition-colors">
          {property.title}
        </h3>
        <p className="text-stone-600 leading-relaxed font-light">
          {property.description}
        </p>
        <div className="pt-4 flex flex-wrap gap-4">
          {property.features.slice(0, 3).map((feature, i) => (
            <span key={i} className="text-[10px] text-stone-400 border border-stone-200 px-2 py-1 uppercase tracking-wider">
              {feature}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
