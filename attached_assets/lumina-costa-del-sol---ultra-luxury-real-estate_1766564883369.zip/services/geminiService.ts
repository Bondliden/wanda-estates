
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateInvestmentInsight = async (propertyName: string, description: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analiza esta propiedad de lujo para un inversor millonario y altamente educado. Genera un breve párrafo (máximo 4 líneas) que destaque el valor intrínseco, la exclusividad y el potencial de plusvalía en la Costa del Sol. Evita lenguaje cursi o de ventas agresivo. Usa un tono sobrio, analítico y distinguido. 
      Propiedad: ${propertyName}
      Descripción: ${description}`,
      config: {
        temperature: 0.7,
        topP: 0.9,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Error generating insight:", error);
    return "Una oportunidad patrimonial definida por la excelencia arquitectónica y la ubicación estratégica en el litoral mediterráneo.";
  }
};
