
import React from 'react';
import AuditTable from './components/AuditTable';
import { PILLARS } from './constants';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header Section */}
      <header className="bg-slate-900 text-white pt-20 pb-40 px-6 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0,100 C20,80 40,80 60,100 C80,120 100,100 100,100 V0 H0 Z" fill="currentColor" />
          </svg>
        </div>
        
        <div className="max-w-7xl mx-auto relative z-10 text-center">
          <div className="inline-block px-4 py-1.5 mb-6 bg-amber-500/20 border border-amber-500/30 rounded-full text-amber-400 text-sm font-semibold tracking-widest uppercase">
            Auditoría Experta 2025
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight">
            Análisis Estratégico <span className="text-amber-500 italic">Wanda Estates</span>
          </h1>
          <p className="text-slate-400 text-xl max-w-2xl mx-auto leading-relaxed font-light">
            Propuesta de optimización basada en los 5 pilares críticos de la ingeniería de ventas inmobiliaria de alto rendimiento.
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 -mt-24">
        {/* Pillars Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-12">
          {PILLARS.map((pillar) => (
            <div key={pillar.type} className="bg-white p-6 rounded-xl shadow-lg border border-slate-100 hover:border-amber-500 transition-all group">
              <div className="text-3xl mb-3 group-hover:scale-110 transition-transform inline-block">{pillar.icon}</div>
              <h3 className="text-slate-800 font-bold text-sm mb-2">{pillar.type}</h3>
              <p className="text-slate-500 text-xs leading-relaxed">{pillar.description}</p>
            </div>
          ))}
        </div>

        {/* Audit Table Section */}
        <div className="mb-20">
          <AuditTable />
        </div>

        {/* Closing Call to Action / Summary */}
        <section className="bg-white rounded-2xl p-10 shadow-xl border border-slate-100 flex flex-col md:flex-row items-center gap-10">
          <div className="flex-1">
            <h2 className="text-3xl font-bold text-slate-800 mb-4">Hoja de Ruta de Implementación</h2>
            <p className="text-slate-600 mb-6 leading-relaxed">
              La transición de Wanda Estates hacia un modelo de **Venta de Alto Rendimiento** requiere una ejecución simultánea de estos ajustes. En 2025, el cliente no solo busca metros cuadrados, busca una autoridad digital que proyecte seguridad y un estilo de vida aspiracional inmediato.
            </p>
            <div className="flex flex-wrap gap-4">
              <span className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                <span className="w-2 h-2 rounded-full bg-green-500"></span> Prioridad SEO: Inmediata
              </span>
              <span className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                <span className="w-2 h-2 rounded-full bg-amber-500"></span> Prioridad UX: 15 días
              </span>
              <span className="flex items-center gap-2 text-sm font-semibold text-slate-700">
                <span className="w-2 h-2 rounded-full bg-blue-500"></span> Innovación IA: Q3 2025
              </span>
            </div>
          </div>
          <div className="bg-slate-900 text-white p-8 rounded-xl w-full md:w-80">
            <h4 className="font-bold text-amber-500 mb-2">Resumen Ejecutivo</h4>
            <div className="space-y-4 text-sm">
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span>KPI Conversión Esperado</span>
                <span className="font-bold">+40%</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span>Mejora en Retención (Time-on-site)</span>
                <span className="font-bold">+2.5m</span>
              </div>
              <div className="flex justify-between">
                <span>Autoridad SEO Local</span>
                <span className="font-bold text-green-400">Excelente</span>
              </div>
            </div>
            <button className="w-full mt-6 bg-amber-600 hover:bg-amber-500 py-3 rounded-lg font-bold transition-all">
              Generar Reporte PDF
            </button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-20 py-10 text-center text-slate-400 border-t border-slate-200">
        <p className="text-sm">Consultoría Wanda Estates 2025 &copy; Powered by AI Strategy Expert</p>
      </footer>
    </div>
  );
};

export default App;
