
export interface AuditItem {
  element: string;
  reason: string;
  suggestion: string;
  pillar: PillarType;
  videoUrl?: string; // Optional URL for demonstration video
}

export enum PillarType {
  COPY = 'Copywriting y Narrativa',
  UX = 'Diseño UX/UI y Estructura',
  SEO = 'SEO Local y Autoridad',
  LEADS = 'Captación de Leads',
  INNOVATION = 'Innovación 2025'
}

export interface PillarInfo {
  type: PillarType;
  icon: string;
  description: string;
}
