
import React from 'react';
import { AuditItem, PillarType, PillarInfo } from './types';

export const PILLARS: PillarInfo[] = [
  {
    type: PillarType.COPY,
    icon: '✍️',
    description: 'Ingeniería de la Persuasión y Proyección a Futuro.'
  },
  {
    type: PillarType.UX,
    icon: '🎨',
    description: 'Retención, Velocidad y Jerarquía Visual.'
  },
  {
    type: PillarType.SEO,
    icon: '📍',
    description: 'Hiperlocalización y Prueba Social.'
  },
  {
    type: PillarType.LEADS,
    icon: '📈',
    description: 'Estrategias de Conversión sin Fricción.'
  },
  {
    type: PillarType.INNOVATION,
    icon: '🤖',
    description: 'Inteligencia Artificial y Experiencias Inmersivas.'
  }
];

export const AUDIT_DATA: AuditItem[] = [
  {
    pillar: PillarType.COPY,
    element: "Titular Principal (Hero Section)",
    reason: "Es genérico y descriptivo. No utiliza 'Future Pacing' ni segmenta al inversor de alto nivel.",
    suggestion: "Cambiar a: 'Tu Legado en la Costa del Sol: Propiedades Exclusivas en la Milla de Oro para Inversores que Exigen lo Extraordinario'. Sustituir 'Ver Propiedades' por 'Explorar tu Próximo Refugio'.",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4" 
  },
  {
    pillar: PillarType.COPY,
    element: "Narrativa de Fichas de Propiedad",
    reason: "Listas frías de características. Falta de palabras sensoriales que evoquen el estilo de vida de Marbella.",
    suggestion: "Sustituir '3 Habitaciones, Orientación Sur' por: 'Tres santuarios de descanso bañados por luz natural ininterrumpida, diseñados para fundirse con el azul del Mediterráneo'. Usar términos como 'refugio', 'oasis' y 'exclusividad'."
  },
  {
    pillar: PillarType.UX,
    element: "Navegación Móvil y CTAs",
    reason: "Botones pequeños y verbos pasivos. El 70% del tráfico inmobiliario es móvil y requiere interacción táctil fluida.",
    suggestion: "Implementar botones de acción de mínimo 48x48px. Cambiar el texto de los botones de 'Enviar' o 'Contacto' a verbos de acción directa como 'Programar Visita VIP' o 'Solicitar Dossier Privado'.",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
  },
  {
    pillar: PillarType.UX,
    element: "Jerarquía Visual (Bento-Box)",
    reason: "Saturación de información lineal. Dificulta la retención visual del usuario premium.",
    suggestion: "Organizar la información clave (Precio, Ubicación, ROI) en módulos tipo Bento-Box. Destacar una 'Propiedad de la Semana' con un diseño minimalista que respire lujo."
  },
  {
    pillar: PillarType.SEO,
    element: "Hiperlocalización Long-tail",
    reason: "Búsquedas genéricas. Falta autoridad en barrios específicos de alto ticket.",
    suggestion: "Crear clusters de contenido para: 'Villas de lujo en La Zagaleta', 'Áticos con vistas en Sierra Blanca' y 'Guía de Inversión en Nueva Andalucía'. Mencionar colegios internacionales y clubes de golf cercanos."
  },
  {
    pillar: PillarType.SEO,
    element: "Prueba Social y Autoridad",
    reason: "Falta de validación externa visible. El mercado de lujo se basa 100% en la confianza.",
    suggestion: "Integrar un carrusel de testimonios reales con fotografía del cliente (si es posible) o logos de partners estratégicos. Añadir sello de 'Expertos en Marbella desde [Año]'."
  },
  {
    pillar: PillarType.LEADS,
    element: "Optimización de Formularios",
    reason: "Exceso de campos (Fricción). Los leads de alto ticket valoran la discreción y rapidez.",
    suggestion: "Simplificar a solo 3 campos: Nombre, Email y WhatsApp. Incluir un checkbox de 'Interés prioritario' (Inversión o Residencia)."
  },
  {
    pillar: PillarType.LEADS,
    element: "Lead Magnets de Valor",
    reason: "Falta de incentivo para dejar datos. Solo contacto directo.",
    suggestion: "Añadir botón de descarga: 'Informe de Mercado Marbella 2025: Dónde invertir este trimestre' o 'Guía VIP para compradores internacionales'."
  },
  {
    pillar: PillarType.INNOVATION,
    element: "Atención IA y Chatbot",
    reason: "Pérdida de leads en horario nocturno (clientes de EE.UU./Asia).",
    suggestion: "Instalar un asistente de IA (ej. con Gemini) que responda: '¿Qué villas tienen más de 500m2 en Puerto Banús?' al instante, 24/7."
  },
  {
    pillar: PillarType.INNOVATION,
    element: "Multimedia Inmersiva",
    reason: "Uso exclusivo de fotografía estática.",
    suggestion: "Priorizar el uso de 'Cinematic Drone Tours' y recorridos virtuales 360º. Estos aumentan las consultas un 403% según estadísticas del sector.",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
  }
];
