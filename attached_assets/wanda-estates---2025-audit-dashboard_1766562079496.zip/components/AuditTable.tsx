
import React, { useState } from 'react';
import { AuditItem, PillarType } from '../types';
import { AUDIT_DATA } from '../constants';
import { getExpertInsight } from '../services/geminiService';
import VideoModal from './VideoModal';

const AuditTable: React.FC = () => {
  const [selectedPillar, setSelectedPillar] = useState<PillarType | 'All'>('All');
  const [insight, setInsight] = useState<{ [key: string]: string }>({});
  const [loading, setLoading] = useState<string | null>(null);
  const [activeVideoItem, setActiveVideoItem] = useState<AuditItem | null>(null);

  const filteredData = selectedPillar === 'All' 
    ? AUDIT_DATA 
    : AUDIT_DATA.filter(item => item.pillar === selectedPillar);

  const handleInsightRequest = async (item: AuditItem) => {
    setLoading(item.element);
    const result = await getExpertInsight(`${item.element} - ${item.reason}`);
    setInsight(prev => ({ ...prev, [item.element]: result }));
    setLoading(null);
  };

  return (
    <div className="w-full overflow-hidden rounded-3xl bg-white shadow-2xl border border-slate-100">
      <div className="p-8 border-b border-slate-100 bg-slate-50/50 flex flex-wrap gap-4 items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 italic">Análisis Detallado</h2>
          <p className="text-slate-500 text-sm">Explora las brechas de conversión y sus soluciones multimedia.</p>
        </div>
        <div className="flex gap-2 p-1 bg-slate-100 rounded-2xl overflow-x-auto no-scrollbar">
          {['All', ...Object.values(PillarType)].map((p) => (
            <button
              key={p}
              onClick={() => setSelectedPillar(p as any)}
              className={`whitespace-nowrap px-5 py-2 rounded-xl text-xs font-bold transition-all duration-300 ${
                selectedPillar === p 
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/20' 
                : 'bg-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              {p === 'All' ? 'Ver Todo' : p}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900 text-white uppercase text-[10px] font-black tracking-[0.2em]">
              <th className="px-8 py-5 w-[22%]">Elemento Crítico</th>
              <th className="px-8 py-5 w-[28%]">Diagnóstico</th>
              <th className="px-8 py-5 w-[30%]">Sugerencia VIP</th>
              <th className="px-8 py-5 text-center w-[20%]">Recursos</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredData.map((item, idx) => (
              <React.Fragment key={idx}>
                <tr className="hover:bg-slate-50/80 transition-all group">
                  <td className="px-8 py-8 align-top">
                    <span className="block text-[10px] font-black text-amber-600 mb-2 tracking-widest uppercase">{item.pillar}</span>
                    <span className="text-slate-900 font-bold text-lg leading-tight group-hover:text-amber-700 transition-colors">{item.element}</span>
                  </td>
                  <td className="px-8 py-8 align-top text-slate-500 text-sm leading-relaxed font-medium italic">
                    "{item.reason}"
                  </td>
                  <td className="px-8 py-8 align-top">
                    <div className="bg-white p-5 rounded-2xl border border-slate-200 text-slate-800 text-xs font-bold leading-relaxed shadow-sm border-l-4 border-l-amber-500">
                      {item.suggestion}
                    </div>
                  </td>
                  <td className="px-8 py-8 align-top">
                    <div className="flex flex-col gap-3">
                      <button
                        onClick={() => handleInsightRequest(item)}
                        disabled={loading === item.element}
                        className="flex items-center justify-center gap-2 w-full py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-md active:scale-95 disabled:opacity-50"
                      >
                        {loading === item.element ? (
                          <span className="flex items-center gap-2">
                            <svg className="animate-spin h-3 w-3" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                            Consultando...
                          </span>
                        ) : (
                          <>
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                            IA Insight
                          </>
                        )}
                      </button>
                      <button
                        onClick={() => setActiveVideoItem(item)}
                        className={`flex items-center justify-center gap-2 w-full py-3 border-2 ${item.videoUrl ? 'bg-amber-500 border-amber-500 text-white' : 'border-slate-200 text-slate-400 hover:border-amber-400 hover:text-amber-600'} rounded-xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95`}
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        {item.videoUrl ? 'Ver Video' : 'Ver Demo'}
                      </button>
                    </div>
                  </td>
                </tr>
                {insight[item.element] && (
                  <tr className="bg-slate-900">
                    <td colSpan={4} className="px-10 py-6 border-l-8 border-amber-500">
                      <div className="flex items-start gap-6 max-w-4xl animate-in fade-in slide-in-from-left-4 duration-500">
                        <div className="bg-amber-500/10 p-3 rounded-2xl flex-shrink-0">
                          <span className="text-2xl">⚡</span>
                        </div>
                        <div className="space-y-2">
                          <h4 className="text-amber-500 font-black text-[10px] uppercase tracking-widest">Estrategia Experta 2025</h4>
                          <p className="text-slate-300 text-sm leading-relaxed italic leading-loose">
                            {insight[item.element]}
                          </p>
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      <VideoModal 
        item={activeVideoItem} 
        onClose={() => setActiveVideoItem(null)} 
      />
    </div>
  );
};

export default AuditTable;
