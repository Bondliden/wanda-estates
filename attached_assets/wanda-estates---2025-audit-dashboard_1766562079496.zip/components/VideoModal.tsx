
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { AuditItem } from '../types';

interface VideoModalProps {
  item: AuditItem | null;
  onClose: () => void;
}

const VideoModal: React.FC<VideoModalProps> = ({ item, onClose }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!item) return null;

  const handleGenerateVideo = async () => {
    // @ts-ignore
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      // @ts-ignore
      await window.aistudio.openSelectKey();
    }

    setIsGenerating(true);
    setError(null);
    setStatusMessage('Iniciando Inteligencia Artificial...');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      setStatusMessage('Diseñando el concepto visual premium...');
      const promptResponse = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Actúa como un experto en marketing inmobiliario de lujo. Crea un prompt para Veo AI basado en: "${item.suggestion}". El video debe evocar exclusividad, arquitectura moderna en Marbella, luz dorada del atardecer y una sensación de "hogar soñado". Prompt en inglés, cinematográfico.`,
      });
      const videoPrompt = promptResponse.text || `Ultra-luxury modern villa in Marbella at sunset, drone cinematic shot, golden hour lighting, 4k, architectural masterpiece.`;

      setStatusMessage('Generando demo cinematográfica con Veo AI...');
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: videoPrompt,
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      });

      let progressIndex = 0;
      const progressMessages = [
        "Capturando la esencia del Mediterráneo...",
        "Simulando texturas de mármol y cristal...",
        "Renderizando iluminación ambiental...",
        "Finalizando post-producción IA..."
      ];

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        setStatusMessage(progressMessages[progressIndex % progressMessages.length] + ' (Procesando...)');
        progressIndex++;
        
        try {
          operation = await ai.operations.getVideosOperation({ operation: operation });
        } catch (e: any) {
          if (e.message?.includes("Requested entity was not found")) {
            // @ts-ignore
            await window.aistudio.openSelectKey();
            throw new Error("Clave de API requerida.");
          }
          throw e;
        }
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (downloadLink) {
        const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const blob = await videoResponse.blob();
        setGeneratedVideoUrl(URL.createObjectURL(blob));
        setStatusMessage('¡Demo lista!');
      } else {
        throw new Error('Error al recuperar video.');
      }

    } catch (err: any) {
      setError(err.message || 'Error en la generación.');
    } finally {
      setIsGenerating(false);
    }
  };

  const videoToPlay = generatedVideoUrl || item.videoUrl;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/95 backdrop-blur-md">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-5xl overflow-hidden relative border border-white/20">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-slate-400 hover:text-white bg-slate-800/50 rounded-full p-2 transition-all z-50"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="flex flex-col md:flex-row min-h-[500px]">
          <div className="md:w-[65%] bg-black flex flex-col items-center justify-center relative">
            {isGenerating ? (
              <div className="text-center p-12">
                <div className="w-16 h-16 rounded-full border-4 border-amber-500/20 border-t-amber-500 animate-spin mx-auto mb-6"></div>
                <h3 className="text-white text-lg font-bold">{statusMessage}</h3>
              </div>
            ) : videoToPlay ? (
              <video src={videoToPlay} className="w-full h-full object-cover" controls autoPlay loop />
            ) : (
              <div className="text-center p-12">
                <span className="text-5xl mb-6 block">📽️</span>
                <h3 className="text-white font-bold text-2xl mb-4">Demo Visual Recomendada</h3>
                <p className="text-slate-400 text-sm mb-8 max-w-xs">
                  Proyecta cómo se vería esta mejora con contenido de video profesional.
                </p>
                <button 
                  onClick={handleGenerateVideo}
                  className="bg-amber-600 hover:bg-amber-500 text-white px-8 py-4 rounded-xl font-bold transition-all flex items-center gap-3 mx-auto"
                >
                  Generar Visual con IA
                </button>
              </div>
            )}
            {error && <div className="absolute bottom-6 bg-red-500 text-white px-4 py-2 rounded-lg text-xs">{error}</div>}
          </div>

          <div className="md:w-[35%] p-10 bg-slate-50 flex flex-col justify-center">
            <span className="text-[10px] font-black text-amber-600 uppercase mb-4 tracking-widest">{item.pillar}</span>
            <h2 className="text-2xl font-bold text-slate-800 mb-4">{item.element}</h2>
            <p className="text-slate-600 text-sm italic mb-8 border-l-2 border-slate-200 pl-4">"{item.reason}"</p>
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <h4 className="text-[10px] font-black text-slate-400 uppercase mb-2">Sugerencia de Implementación</h4>
              <p className="text-xs text-slate-800 leading-relaxed font-semibold">{item.suggestion}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoModal;
